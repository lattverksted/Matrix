var searchData=
[
  ['main_30',['main',['../test_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'test.cpp']]],
  ['matrix_31',['Matrix',['../class_matrix.html#a7213414e405fd1c81c394d5053721fa7',1,'Matrix::Matrix(int rows, int cols)'],['../class_matrix.html#a8fad4f8f910df650caff2d272a9255d9',1,'Matrix::Matrix(int rows, int cols, double value)']]],
  ['multiply_32',['multiply',['../class_matrix.html#aaa9e61c8e1e87cdd7c34ee8690f37190',1,'Matrix']]]
];
