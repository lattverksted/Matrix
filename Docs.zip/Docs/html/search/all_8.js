var searchData=
[
  ['rows_16',['Rows',['../class_matrix.html#ab47018763c47555749145cc47b6ac979',1,'Matrix']]]
];
