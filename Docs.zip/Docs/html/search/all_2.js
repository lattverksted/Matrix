var searchData=
[
  ['display_2',['display',['../class_matrix.html#a9ddfdc3fd20ed06d2735f79449720ffc',1,'Matrix']]]
];
