var searchData=
[
  ['_7ematrix_18',['~Matrix',['../class_matrix.html#a9b1c3627f573d78a2f08623fdfef990f',1,'Matrix']]]
];
