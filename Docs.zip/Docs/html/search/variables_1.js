var searchData=
[
  ['cols_37',['Cols',['../class_matrix.html#a56b4031b917b374c768d52a2a71eb501',1,'Matrix']]]
];
