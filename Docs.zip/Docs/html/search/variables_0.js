var searchData=
[
  ['array_36',['Array',['../class_matrix.html#a73d501d32befe3612c1c133e9b590983',1,'Matrix']]]
];
