var searchData=
[
  ['operator_2a_14',['operator*',['../class_matrix.html#a77109678219b5ceafe82b63c73f9ff20',1,'Matrix::operator*(Matrix &amp;b)'],['../class_matrix.html#ab1f006b8a933f8883d23cf5364af40a8',1,'Matrix::operator*(double scalar)']]],
  ['operator_2b_15',['operator+',['../class_matrix.html#af0722ceaa06d860a236378a04f610942',1,'Matrix']]]
];
