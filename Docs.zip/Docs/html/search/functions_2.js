var searchData=
[
  ['getarray_25',['getArray',['../class_matrix.html#af7335bac0b231a6dc72f69476c0bd6fe',1,'Matrix']]],
  ['getcols_26',['getCols',['../class_matrix.html#af8f8c1b3a03c4bb281571ac449406fe5',1,'Matrix']]],
  ['getrows_27',['getRows',['../class_matrix.html#a8b0973eaa4ce4924f10d9bbf7630c07b',1,'Matrix']]]
];
